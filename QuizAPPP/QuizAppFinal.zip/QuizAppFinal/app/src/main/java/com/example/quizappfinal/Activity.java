package com.example.quizappfinal;

public class Activity extends android.app.Activity {
}
