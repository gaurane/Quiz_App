package com.example.quizappfinal;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.quizappfinal.EndActivity;
import com.example.quizappfinal.R;

public class QuizActivity extends AppCompatActivity {

    private TextView questionText, questionNumber, timerText;
    private RadioButton option1, option2, option3, option4;
    private RadioGroup optionsGroup;
    private Button nextButton, prevButton;
    private ProgressBar progressBar;

    private String[] questions = {
            "Which programming language is primarily used for Android app development?",
            "What is the official IDE for Android development?",
            "What is an APK file in Android development?",
            "Which layout is best for complex designs with nested views?",
            "What is the main entry point for an Android app?",
            "Which component is used to display a single screen in Android?",
            "Which XML attribute is used to set the width and height of a view?",
            "What is an Intent in Android?",
            "Which permission is required to access the internet in an Android app?",
            "What is the latest programming language officially supported by Android?",
            "Which Android component is used to handle background tasks?",
            "Which Android component is used to share data between apps?",
            "What is the default database used in Android development?",
            "Which design pattern is widely used in Android development?",
            "What is the purpose of the Manifest file in an Android app?"
    };

    private String[][] options = {
            {"Python", "Java", "Swift", "PHP"},
            {"Eclipse", "Visual Studio", "Android Studio", "NetBeans"},
            {"Android Program Kit", "Android Package Kit", "Android Processing Key", "Application Programming Kit"},
            {"LinearLayout", "RelativeLayout", "ConstraintLayout", "FrameLayout"},
            {"Main.java", "MainActivity.kt", "AppStart.xml", "SplashScreen.java"},
            {"Service", "BroadcastReceiver", "Activity", "Fragment"},
            {"layout_width and layout_height", "width and height", "size_width and size_height", "dimension_width and dimension_height"},
            {"A background task", "Used to switch between activities", "To create a layout", "To store data"},
            {"<uses-permission android:name=\"android.permission.ACCESS_WIFI\"/>",
                    "<uses-permission android:name=\"android.permission.INTERNET\"/>",
                    "<uses-permission android:name=\"android.permission.DATA\"/>",
                    "<uses-permission android:name=\"android.permission.NET\"/>"},
            {"Java", "Kotlin", "Swift", "C++"},
            {"Activity", "Service", "Content Provider", "Fragment"},
            {"Activity", "Broadcast Receiver", "Content Provider", "Service"},
            {"MySQL", "SQLite", "PostgreSQL", "Firebase"},
            {"MVC", "MVVM", "Singleton", "Factory"},
            {"To design the user interface", "To declare app permissions, activities, and app metadata",
                    "To handle background tasks", "To manage app storage"}
    };

    private int[] correctAnswers = {1, 2, 1, 2, 1, 2, 0, 1, 1, 1, 1, 2, 1, 1, 1};

    private int currentQuestionIndex = 0;
    private int score = 0;
    private int totalQuestions = questions.length;
    private CountDownTimer countDownTimer;
    private static final int TIMER_DURATION = 10000; // 10 seconds
    private int progressStep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionText = findViewById(R.id.questionText);
        questionNumber = findViewById(R.id.questionNumber);
        timerText = findViewById(R.id.timerText);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        optionsGroup = findViewById(R.id.optionsGroup);
        nextButton = findViewById(R.id.nextButton);
        prevButton = findViewById(R.id.prevButton);
        progressBar = findViewById(R.id.progressBar);

        progressStep = 100 / totalQuestions;
        loadQuestion();

        nextButton.setOnClickListener(v -> nextQuestion());
        prevButton.setOnClickListener(v -> previousQuestion());
    }

    private void loadQuestion() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(TIMER_DURATION, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerText.setText("Time: " + millisUntilFinished / 1000 + "s");
            }

            @Override
            public void onFinish() {
                nextQuestion();
            }
        }.start();

        questionNumber.setText("Question " + (currentQuestionIndex + 1) + "/" + totalQuestions);
        questionText.setText(questions[currentQuestionIndex]);
        option1.setText(options[currentQuestionIndex][0]);
        option2.setText(options[currentQuestionIndex][1]);
        option3.setText(options[currentQuestionIndex][2]);
        option4.setText(options[currentQuestionIndex][3]);
        optionsGroup.clearCheck();
        progressBar.setProgress((currentQuestionIndex + 1) * progressStep);
    }

    private void nextQuestion() {
        checkAnswer();
        if (currentQuestionIndex < totalQuestions - 1) {
            currentQuestionIndex++;
            loadQuestion();
        } else {
            endQuiz();
        }
    }

    private void previousQuestion() {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--;
            loadQuestion();
        }
    }

    private void checkAnswer() {
        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedOption = findViewById(selectedId);
            int selectedIndex = optionsGroup.indexOfChild(selectedOption);
            if (selectedIndex == correctAnswers[currentQuestionIndex]) {
                score++;
            }
        }
    }

    private void endQuiz() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        Intent intent = new Intent(QuizActivity.this, EndActivity.class);
        intent.putExtra("SCORE", score);
        intent.putExtra("TOTAL", totalQuestions);
        startActivity(intent);
        finish();
    }
}
