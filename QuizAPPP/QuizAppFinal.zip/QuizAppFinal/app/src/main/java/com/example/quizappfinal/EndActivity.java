package com.example.quizappfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.quizappfinal.R;
import com.example.quizappfinal.StartActivity;

public class EndActivity extends AppCompatActivity {

    private TextView scoreText;
    private Button restartButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);

        scoreText = findViewById(R.id.score_text);
        restartButton = findViewById(R.id.restart_button);

        // Retrieve score from intent
        int score = getIntent().getIntExtra("SCORE", 0);
        int totalQuestions = getIntent().getIntExtra("TOTAL", 0);

        // Display final score
        scoreText.setText("Your Score: " + score + " / " + totalQuestions);

        // Restart button to go back to StartActivity
        restartButton.setOnClickListener(v -> {
            Intent intent = new Intent(EndActivity.this, StartActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
